package com.nagarro.restbackApi.Enums;

public enum NAGPStatus {
	ASPIRING,
	TAGGED,
	DROPPED 
}
