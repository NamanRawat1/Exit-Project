package com.nagarro.restbackApi.Enums;

public enum Status {
	PLANNED, 
	IN_PROGRESS, 
	DONE,
	REVIEW_PENDING, 
	COMPLETED,
	REVIEW_FAILED
}
